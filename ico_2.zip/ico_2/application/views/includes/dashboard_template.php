<?php $this->load->view('includes/dashboard_header'); ?>
<?php $this->load->view($main_content); ?>
<?php $this->load->view('includes/dashboard_footer'); ?>
