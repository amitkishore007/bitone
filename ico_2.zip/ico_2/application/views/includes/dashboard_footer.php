 </div>
    <script src="<?php echo base_url('assets/dashboard/'); ?>lib/jquery/jquery.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/dashboard/'); ?>lib/perfect-scrollbar/js/perfect-scrollbar.jquery.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/dashboard/'); ?>js/main.js" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/dashboard/'); ?>lib/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- <script src="<?php echo base_url('assets/dashboard/'); ?>/jquery-flot/jquery.flot.js" type="text/javascript"></script> -->
    <!-- <script src="<?php echo base_url('assets/dashboard/'); ?>/jquery-flot/jquery.flot.pie.js" type="text/javascript"></script> -->
    <!-- <script src="<?php echo base_url('assets/dashboard/'); ?>/jquery-flot/jquery.flot.resize.js" type="text/javascript"></script> -->
    <!-- <script src="<?php echo base_url('assets/dashboard/'); ?>/jquery-flot/plugins/jquery.flot.orderBars.js" type="text/javascript"></script> -->
    <!-- <script src="<?php echo base_url('assets/dashboard/'); ?>/jquery-flot/plugins/curvedLines.js" type="text/javascript"></script> -->
    <script src="<?php echo base_url('assets/dashboard/'); ?>lib/jquery.sparkline/jquery.sparkline.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/dashboard/'); ?>lib/countup/countUp.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/dashboard/'); ?>lib/jquery-ui/jquery-ui.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/dashboard/'); ?>lib/jqvmap/jquery.vmap.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/dashboard/'); ?>lib/jqvmap/maps/jquery.vmap.world.js" type="text/javascript"></script>
    <script src='<?php echo base_url('assets/'); ?>js/script.js' type="text/javascript"></script>
    <script type="text/javascript" > 

         var ajax_url = '<?php echo base_url(); ?>';

    </script>

  </body>

</html>