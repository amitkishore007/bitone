
<section  class="main-section gradient-color  login">
    <!-- Overlay Color -->
    
    <div class="container">
        <div class="row">
            <!-- Single Show Case -->
            <div class="col-md-6 col-md-offset-3 ">
                
            <div class="contact">
                <!--Title-->
                <p class="text-center" style="color:#c10f41;"> <i class="fa fa-exclamation-circle" aria-hidden="true" style="font-size: 3em;"></i></p>
                <h4 class="text-center p-b-2">Please verify your email address</h4>
         
                <p class="text-center">An email has been sent to your email address, please follow the instruction to continue!</p>
            </div>
        </div>
    </div>
</section>
<!-- Start Features Section-->
