
<section  class="main-section gradient-color  login">
    <!-- Overlay Color -->
    
    <div class="container">
        <div class="row">
            <!-- Single Show Case -->
            <div class="col-md-6 col-md-offset-3 ">
                
            <div class="contact">
                <!--Title-->
                <p class="text-center" style="color:#1fa67a;"> <i class="fa fa-check-circle" aria-hidden="true" style="font-size: 3em;"></i></p>
                <h4 class="text-center p-b-2">Email verified successfully</h4>
         
                <p class="text-center"><a class='btn btn-primary' href="<?php echo base_url('login'); ?>">PLease login</a></p>
            </div>
        </div>
    </div>
</section>
<!-- Start Features Section-->
